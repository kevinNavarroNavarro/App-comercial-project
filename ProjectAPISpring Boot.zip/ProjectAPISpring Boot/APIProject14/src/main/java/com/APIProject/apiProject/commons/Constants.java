package com.APIProject.apiProject.commons;

public class Constants {
    public static final String AUTHORIZATION_HEADER = "Authorization";
    public static final String AUTHORIZATION_HEADER_PREFIX = "Bearer ";
    public static final String SECRET_KEY = "thisIsAVerySecureSecretKey";
    public static final String JWT_ID = "idForJwtSessionUniqueForFuelControlApp";
}
