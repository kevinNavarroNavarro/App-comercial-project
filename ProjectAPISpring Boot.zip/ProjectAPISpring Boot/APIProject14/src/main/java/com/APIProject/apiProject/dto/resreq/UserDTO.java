package com.APIProject.apiProject.dto.resreq;

public class UserDTO {
}
