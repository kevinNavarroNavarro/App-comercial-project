package com.APIProject.apiProject.exceptions.security;

public class DuplicatedUserException extends RuntimeException  {
}
