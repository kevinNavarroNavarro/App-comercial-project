package com.APIProject.apiProject.repository;

import com.APIProject.apiProject.domain.business.SIssue;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SIssueRepository extends JpaRepository<SIssue, Integer> {

}
