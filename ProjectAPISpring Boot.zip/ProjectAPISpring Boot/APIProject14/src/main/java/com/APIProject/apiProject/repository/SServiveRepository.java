package com.APIProject.apiProject.repository;

import com.APIProject.apiProject.domain.business.SService;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SServiveRepository extends JpaRepository<SService, Integer> {

}
