package com.APIProject.apiProject.repository;

import com.APIProject.apiProject.domain.business.Supervisor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SupervisorRepository extends JpaRepository<Supervisor, Integer> {
}

