package com.APIProject.apiProject.repository;

import com.APIProject.apiProject.domain.business.Supporter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SupporterRepository extends JpaRepository<Supporter, Integer> {

}
